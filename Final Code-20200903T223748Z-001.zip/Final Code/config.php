<?php

$users = array(
    array(
        'id' => 0,
        'username' => 'john',
        'password' => 'password',
    ),
    array(
        'id' => 1,
        'username' => 'james',
        'password' => 'password',
    ),
    array(
        'id' => 2,
        'username' => 'jill',
        'password' => 'password',
    )
);
?>