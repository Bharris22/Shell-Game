<div id="underline">
<h1>Login</h1>
</div>
<link rel="stylesheet" type="text/css" media="screen" href="./css/login.css">

<div id="form">
<form action="process.php" method="post">
	<label>Username</label>
	<input type="text" name="username">
	<label>Password</label>
	<input type="password" name="password">

	<br><br>
	<input type="submit" name="button" value="submit">
</form>
</div>
