<h1>Welcome home <?php echo $user['username']; ?></h1>
<p>You are logged in!</p>
<p>Click here to <a href="logout.php">log out</a></p>